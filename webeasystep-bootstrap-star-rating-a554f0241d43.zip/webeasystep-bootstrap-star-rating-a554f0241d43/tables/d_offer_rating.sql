-- phpMyAdmin SQL Dump
-- version 4.2.7.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 30, 2015 at 09:33 AM
-- Server version: 5.5.39
-- PHP Version: 5.4.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dtworks_travel`
--

-- --------------------------------------------------------

--
-- Table structure for table `d_offer_rating`
--

CREATE TABLE IF NOT EXISTS `d_offer_rating` (
`ort_id` int(11) NOT NULL,
  `ort_item_id` int(11) NOT NULL,
  `ort_total_rates` int(11) NOT NULL,
  `ort_total_points` decimal(10,1) NOT NULL
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `d_offer_rating`
--

INSERT INTO `d_offer_rating` (`ort_id`, `ort_item_id`, `ort_total_rates`, `ort_total_points`) VALUES
(1, 8, 1, '1.5');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `d_offer_rating`
--
ALTER TABLE `d_offer_rating`
 ADD PRIMARY KEY (`ort_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `d_offer_rating`
--
ALTER TABLE `d_offer_rating`
MODIFY `ort_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=2;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
