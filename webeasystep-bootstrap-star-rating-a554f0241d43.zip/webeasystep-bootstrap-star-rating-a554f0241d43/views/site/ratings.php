<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Jquery Raty usage in PHP - Simple Star Ratting Plugin</title>
    <!-- Placed at the end of the document so the pages load faster -->
    <link href="http://netdna.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="<?= base_url() ?>global/site/rating/js/star-rating.js" type="text/javascript"></script>
    <link href="<?= base_url() ?>global/site/rating/css/star-rating.css" media="all" rel="stylesheet" type="text/css"/>

</head>
<body>
<script type="text/javascript">

    $(function () {
        $('.rating').on('rating.change', function (event, value, caption) {
            var rate_id = $(this).prop('id');
            var pure_id = rate_id.substring(6);
            $.post('<?= base_url()?>rating/create_rate', {score: value, pid: pure_id},
                function (data) {
                    $('#' + rate_id).rating('refresh', {
                        showClear: false,
                        showCaption: false,
                        disabled: true
                    });
                });
            console.log(value);
            console.log(pure_id);
        });
    });
</script>
                                <span class="dist dist-xs">

                                   <span dir="ltr" class="inline">
                                    <input id="input-<?= $offer->of_id ?>" name="rating"
                                        <?php if ($offer->ort_total_rates > 0 or $offer->ort_total_points > 0) { ?>
                                            value="<?php echo $offer->ort_total_points / $offer->ort_total_rates ?>"
                                        <?php } else { ?>
                                            value="0"
                                        <?php } ?>
                                        <?php if ($this->session->userdata('logged_in') == false) { ?>
                                            data-disabled="true"
                                        <?php } else { ?>
                                            data-disabled="<?= modules::run("rating/is_rated", $offer->of_id) ?>"
                                        <?php } ?>
                                           class="rating "
                                           min="0" max="5" step="0.5" data-size="xs"
                                           accept="" data-symbol="&#xf005;" data-glyphicon="false"
                                           data-rating-class="rating-fa">
                                </span>
                        <!-- Jquery and Raty Js with scrpt having class star -->


</body>
</html>
