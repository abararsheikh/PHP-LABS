<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class rating extends front_end
{
    // default user and item id ,you can change
    public $user_id = 0 ;
    public $item_id = 0;

    function __construct()
    {
        parent::__construct();

        $this->lang->load('rating/rating');
        $this->load->model('rating_model','rating');
        $this->load->library('form_validation');
    }

    /**
     *  display all ratings in specfic item.
     */
    function index($item_id = 0)
    {
        $data['offer'] = $this->offers->get_detail($item_id);
        $this->load->view('site/ratings',$data);
    }


    function is_rated ($item_id){
        $this->user_id = $this->session->userdata("uid");
        $rated = $this->rating->get_rate_numbers($item_id,$this->user_id);
        if($rated == 0 ) {
            return false;
        }else{
            return true;
        }
    }
    // create new rate
    function create_rate()
    {
            $this->user_id = $this->session->userdata("uid");
            $item_id = $this->input->post("pid");
            $rate =  $this->input->post("score");
            //check the item is rated already
             $rated = $this->is_rated($item_id);

        if($rated == 0 ) {
                // if no send new rate record
               $this->rating->insert_rate($item_id,$rate,$this->user_id);
            }else {
                // else get offer rate id and update value
                $rate_id = $this->rating->get_item_rate($item_id);
                $this->rating->update_rate($rate_id->ort_id,$rate,$this->user_id);

            }

    }



}

/* End of file dashboard.php */
/* Location: ./system/application/modules/matchbox/controllers/dashboard.php */