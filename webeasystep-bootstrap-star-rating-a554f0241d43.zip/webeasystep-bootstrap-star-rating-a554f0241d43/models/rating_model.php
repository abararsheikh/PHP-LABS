<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class rating_model extends CI_Model {

    function __construct() {
        parent::__construct();
    }


    /*  This function get ratings count number
    related to specfic item id.
     */
    function get_detail($of_id)
    {
        return $this->db->query("SELECT *
FROM d_offers
  LEFT JOIN d_offer_rating ON d_offers.of_id = d_offer_rating.ort_item_id
                                 WHERE of_id='$of_id' GROUP BY of_id")->row();
    }

    function get_rate_numbers($item_id,$user_id) {
        $rate_num = $this->db->query("select * from
 d_offer_rating INNER JOIN d_rating_counter ON d_offer_rating.ort_id = d_rating_counter.rtc_rate_id
 where ort_item_id='$item_id' AND rtc_user_id = $user_id")->num_rows();
        return $rate_num;
    }



    /*
 * This function check if user
    has rated specfic item or not
*/
    function get_user_numrate($item_id,$userid) {
        $rate_num = $this->db->query("
        select * from d_offer_rating
         INNER JOIN d_rating_counter ON rtc_rate_id = ort_id
         where ort_item_id ='$item_id'
         AND  rtc_user_id ='$userid' ");
        if ($rate_num->num_rows() > 0) {
            return true;
        }else{
            return false;
        }
    }

    /*  This function get ratings
    related to specfic item id. */

    function get_item_rate($item_id) {
        $query = $this->db->query("select * from d_offer_rating where ort_item_id='$item_id'");
        if ($query->num_rows() > 0)
        {
            $result = $query->row();
            return $result;

        }else{
            return false;
        }
    }


    /*  This function insert ratings
    with item id and user id. */

    function insert_rate($id,$rate,$user_id) {
        $this->db->query("insert into d_offer_rating values('','$id','1','$rate')");
        $last_id = mysql_insert_id();
        $this->db->query("insert into d_rating_counter values('',$last_id,$user_id,UNIX_TIMESTAMP())");
        return true;
    }

    function insert_provider_rate($id,$rate,$user_id) {
        $this->db->query("insert into d_user_rating values('','$id','1','$rate')");
        $last_id = mysql_insert_id();
        $this->db->query("insert into d_rating_counter values('',$last_id,$user_id,UNIX_TIMESTAMP())");
        return true;
    }

    function update_rate($id,$rate,$user_id) {

        $upadte_rate1=$this->db->query("select * from d_offer_rating where ort_item_id='$id'")->row();

        $total_rates= $upadte_rate1->ort_total_rates+1;
        $total_points= $upadte_rate1->ort_total_points+$rate;
        $rate_id= $upadte_rate1->ort_id;
        $this->db->query("update d_offer_rating set ort_total_rates='$total_rates', ort_total_points='$total_points' where ort_id='$rate_id'");
        $this->db->query("insert into d_rating_counter values('','$id',$user_id,UNIX_TIMESTAMP())");

        return true;
    }

    function update_provider_rate($id,$rate,$user_id) {

        $upadte_rate1=$this->db->query("select * from d_user_rating where urt_item_id='$id'")->row();

        $total_rates= $upadte_rate1->urt_total_rates+1;
        $total_points= $upadte_rate1->urt_total_points+$rate;
        $rate_id= $upadte_rate1->urt_id;
        $this->db->query("update d_user_rating set urt_total_rates='$total_rates', urt_total_points='$total_points' where urt_id='$rate_id'");
        $this->db->query("insert into d_rating_counter values('','$id',$user_id,UNIX_TIMESTAMP())");

        return true;
    }

    /*  This function get all categories of city from database sort by order asc. */

    function rating_feed() {
        $this->db->order_by('rating_ord', 'asc');
        $this->db->where('rating_hide', 1);

        $result = $this->db->get('d_offer_rating');
        return $result->result_array();
    }

    function rating_box() {
        $this->db->limit(10);
        $this->db->order_by('rating_ord', 'asc');
        $this->db->where('rating_hide', 1);
        $this->db->select("rating_name");
        $result = $this->db->get('d_offer_rating');
        return $result->result_array();
    }

    function getNumUsersAdmin() {
        $query = $this->db->query("select * from d_offer_rating");
        return $query->num_rows();
    }

    /* This function delete categor of new from database. */

    function delete($id) {
        $this->db->where('rating_id', $id);
        $this->db->delete('d_offer_rating');
        return TRUE;
    }

    function is_valid_category($id) {
        $this->db->where('rating_id', $id);
        $this->db->from('d_offer_rating');
        if ($this->db->count_all_results() > 0) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function is_valid_page($id) {
        $this->db->where('rating_id', $id);
        $this->db->from('d_offer_rating');
        if ($this->db->count_all_results() > 0) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function get_category($id) {
        $this->db->where('rating_id', $id);
        $result = $this->db->get('d_offer_rating');
        if ($result->num_rows() > 0) {
            return $result->row_array();
        } else {
            return FALSE;
        }
    }


}
