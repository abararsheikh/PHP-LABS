<?php
/**
 * Created by PhpStorm.
 * User: ran
 * Date: 3/6/2016
 * Time: 10:15 AM
 */


//DB
define('DATA_SOURCE_NAME','mysql:host=localhost;dbname=php_project');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
?>