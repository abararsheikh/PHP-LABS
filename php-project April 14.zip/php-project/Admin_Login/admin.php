<?php
//include '../autoloader.php';
//$getUserName =\Project\Auth\models\AuthModel::getUser('username');

//var_dump($getUserName);
?>
<html>
<head>
     <meta charset="utf-8" />
    
  <link rel="stylesheet" type="text/css" href="admin.css" />
    <link rel="stylesheet" type="text/css" href="../../Admin_Login/admin.css" />
    <script src ="jquery-1.11.1.js"></script>
    <script src ="admin.js"></script>
</head>
<body>
   
    <div id ="header">
        <div class="logo">
        <a href="#">Welcome to admin page</a>
        </div>
    </div>

    <div id ="container">
        <div class="sidebar">
            <ul id="nav">
                <li><a class = "selected" href ="#">Dashboard</a></li>
                <li><a href ="/FilmAdmin_CMS/view/IndexMovies_AdminView.php">Movies</a></li>
                <li><a href ="#">Events</a></li>
                <li><a href ="#">News</a></li>
                <li><a href ="#">Add new feature</a></li>
                <li><a href ="#">Add new feature</a></li>
                <li><a href ="#">Add new feature</a></li>
            
            </ul>
        
        </div>
        <!--
          <div class="content">
          <h1>Dashboard</h1>
              <p>Here you can do stuff</p>

              <div id ="box">
                  <div class ="box-top">Latest Movies</div>
                  <div class ="box-panel">Add your movie info here.</div>
              </div>

              <div id ="box">
                  <div class ="box-top">Latest Movies</div>
                  <div class ="box-panel">Add your movie info here. ...</div>
              </div>

              <div id ="box">
                  <div class ="box-top">Latest Movies</div>
                  <div class ="box-panel">Add your movie info here....</div>
              </div>

          </div>

          -->

      </div>

</body>
</html>