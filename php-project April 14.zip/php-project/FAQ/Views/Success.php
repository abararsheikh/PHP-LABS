<?php
/**
 * Created by PhpStorm.
 * User: ran
 * Date: 4/10/2016
 * Time: 12:03 PM
 */
?>

<html>
<head>

</head>
<body>
    <h2>Success</h2>
</body>
</html>
