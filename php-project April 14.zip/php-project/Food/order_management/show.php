
<table class="table table-hover">
                     <thead><td>Food</td><td>Price(CAD)</td><td>Quantity</td><td>Payment</td><td>State</td><td>Operation</td></thead>

    <tr style="background-color:salmon;"><td>2012-3-6</td><td>Order ID:0001</td><td colspan="4"></td></tr>
     <tr>                <td rowspan="4"><a href="#"><img src="../../Assets/image/food/food1.jpg" width="130" height="95"/></a></td>
         <td rowspan="4">2.00</td>
         <td rowspan="4">5</td>
         <td rowspan="4">10.00</td>
         <td rowspan="4">Successful deal</td>
         <td rowspan="2">
             <p><a htef="" style="cursor: pointer;text-decoration: none;">Delete</a></p>
            <p> <a htef="" style="cursor: pointer;text-decoration: none;">Make a comment</a></p>
         </td>

     </tr>


                     <tr></tr>
                     <tr>

                     </tr>
                     <tr></tr>
    <tr style="background-color:salmon;"><td>2012-3-6</td><td>Order ID:0001</td><td colspan="4"></td></tr>
    <tr>                <td rowspan="4"><a href="#"><img src="../../Assets/image/food/food1.jpg" width="130" height="95"/></a></td>
        <td rowspan="4">2.00</td>
        <td rowspan="4">5</td>
        <td rowspan="4">10.00</td>
        <td rowspan="4">Unpaid</td>
        <td rowspan="2">
            <p><a htef="" style="cursor: pointer;text-decoration: none;">Delete</a></p>

        </td>

    </tr>


    <tr></tr>
    <tr>

    </tr>
    <tr></tr>

                 </table>
