<?php
?>
<table class="table table-hover">
                <thead><td><input type="checkbox" class="check"></td><td>Select all</td><td colspan="2">Food information</td><td>Price(CAD)</td><td>Quantity</td><td>Amount</td><td>Operation</td></thead>
                <tr>
                  <td rowspan="4"><input type="checkbox" class="check"/> </td>
                    <td rowspan="4"><a href="#"><img src="../Assets/image/food/food1.jpg" width="130" height="95"/></a></td><td rowspan="4">Good food</td><td rowspan="4">Catatory:</td>
                    <td rowspan="4">1.80</td>


                    <td rowspan="4">
                       <div class="snip"><input type="button" value="-" /><input type="text" size="1" maxlength="3"/><input type="button" value="+"/></div>
                    </td><td rowspan="4">10.00</td><td rowspan="4"><a htef="" id="delete">Delete</a></td>
                </tr>
<tr></tr>
                <tr></tr>
                <tr></tr>
                <tr>
                    <td rowspan="4"><input type="checkbox" class="check"/> </td>
                    <td rowspan="4"><a href="#"><img src="../Assets/image/food/food1.jpg" width="130" height="95" /></a></td><td rowspan="4">Good food</td><td rowspan="4">Catatory:</td>
                    <td rowspan="4">1.80</td>


                    <td rowspan="4">
                        <div class="snip"><input type="button" value="-" /><input type="text" size="1" maxlength="3"/><input type="button" value="+"/></div>
                    </td><td rowspan="4">10.00</td><td rowspan="4"><a htef="" id="delete">Delete</a></td>
                </tr>
            </table>