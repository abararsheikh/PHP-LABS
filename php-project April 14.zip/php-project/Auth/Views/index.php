<?php
/**
 * @Author Yi Zhao
 *
 */

?>
<script>System.import('/Auth/Views/auth/adminLogin')</script>
<div id="adminLogin"></div>

<!-- uncomment this when to use bundled file -->
<!--<script src="/Assets/js/authPage.js"></script>-->
