import keyMirror from 'keymirror';

export default keyMirror({
  CHANGE_VIEW: null,
  GET_LOGIN: null,
  LOGOUT: null,
  LOGIN: null,
  ADMIN_LOGIN: null
});