import keyMirror from 'keymirror';

export default keyMirror({
  UPDATE_ERROR: null,
  CHECK_AVAILABILITY: null,
  SUBMIT: null
})