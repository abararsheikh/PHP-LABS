import React from 'react';

export default class PageList extends React.Component {

  render() {
    return (
        <div>
          <ul>
            <li>test</li>
          </ul>
        </div>
    )
  }
}