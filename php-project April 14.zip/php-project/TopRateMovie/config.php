<?php
// HTTP
define('HTTP_SERVER', 'http://localhost:8888/phpPage/admin/');
define('HTTP_CLIENT', 'http://localhost:8888/phpPage/');

//DIR

//DB
define('DB_DRIVER', 'mysqli');
define('DB_HOST','localhost');
define('DB_USERNAME','root');
define('DB_PASSWORD','');
define('DB_DATABASE','php_project');
define('DB_PORT','3306');
