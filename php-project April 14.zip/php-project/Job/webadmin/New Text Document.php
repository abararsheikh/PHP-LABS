web_add.php  添加职位招聘信息页面

user_admin.php  应聘信息页面

test_add.php  测试问题添加

shiti_admin.php  分数

session_Abandon.php  销毁session,退出登录



index.php 网站后台首页

css_Left.css 首页左边样式表

conn.php  网站核心文件，数据库登录

ceshizhanshi.php  测试展示页面

admin_index_top.php  后台首页上部分 

admin_index_Main.php 后台首页头部

admin_index_Left.php 后台首页左侧

admin_index.php 后台首页整合代码

admin_add.php 管理员添加

addzhanshi.php  展示页面添加

index.htm 响应式首页

xiangxi.html响应式附页

index.php首页逻辑


xiangxi.php 附页逻辑
