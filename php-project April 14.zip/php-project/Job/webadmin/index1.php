
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html; charset=gb2312">
  <title></title>
</head>

<table width="100%" border="0">
  <tr>
    <td width="12%"><?php 
require("Admin_Index_Left.php");
?></td>
    <td width="88%"><iframe   width="1000" height="600" name="main" src=""></iframe></td>
  </tr>
</table>

</html>

