<http>
    <head>

    </head>
    <body>
    <table id="output" width="1032" height="1029" border="0" align="center" bordercolor="#CCCCCC" bgcolor="#CCCCCC">
        <tr>
            <td width="135" valign="middle" bgcolor="#CCCCCC">&nbsp;</td>
            <td height="85" bgcolor="#CCCCCC">&nbsp;</td>
        </tr>
        <tr bordercolor="#CCCCCC">
            <td width="135" valign="top" bgcolor="#CCCCCC">
                <table width="157" border="0">
                    <tr id="nav">
                        <td height="64" align="center" valign="middle"><a href="aboutus.php?home"><img src="img/pic1.jpg"></a></td>
                    </tr>
                    <tr>
                        <td height="68" align="center" valign="middle"><a href="Feedback.php?products"><img src="img/pic2.jpg"></a></td>
                    </tr>
                    <tr>
                        <td height="57" align="center" valign="middle"><a href="xiangxi.php?about"><img src="img/pic3.jpg"></a></td>
                    </tr>
                </table>
                <h1>From........................................</h1>
                </td>

            </tr>
        </table>


    </body>

</http>

