
  <div id="menuEditor"></div>
  <script src="/Assets/js/MenuEditor.js"></script>