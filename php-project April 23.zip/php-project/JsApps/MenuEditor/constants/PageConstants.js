import keyMirror from 'keymirror';

export default keyMirror({
  GET_LIST: null
});