import React from 'react';
import ReactDOM from 'react-dom';
import TrailerApp from './components/TrailerApp';

ReactDOM.render(<TrailerApp />, document.querySelector('#trailerApp'));