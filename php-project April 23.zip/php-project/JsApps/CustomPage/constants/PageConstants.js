import keyMirror from 'keymirror';

export default keyMirror({
  GET_LIST: null,
  CHANGE_PAGE: null,
  SAVE: null,
  NEW_PAGE: null,
  GET_PAGE: null,
  DELETE_PAGE: null
});