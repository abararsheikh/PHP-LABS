import React from 'react';
import ReactDOM from 'react-dom';
import Container from './components/Container';
import 'AlloyEditor/dist/alloy-editor/alloy-editor-no-react';

ReactDOM.render(<Container />, document.querySelector('#customPage'));