
  <link href="/jspm_packages/npm/alloyeditor@1.0.1/dist/alloy-editor/assets/alloy-editor-ocean-min.css" rel="stylesheet">

  <script>
    window.ALLOYEDITOR_BASEPATH = '/jspm_packages/npm/alloyeditor@1.0.1/dist/alloy-editor/';
    window.CKEDITOR_BASEPATH = '/jspm_packages/npm/alloyeditor@1.0.1/dist/alloy-editor/';
  </script>

  <div id="customPage"></div>

  <script src="/Assets/js/jquery.min.js"></script>
  <script src="/Assets/js/CustomPage.js"></script>
