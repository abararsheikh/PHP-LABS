<?php

error_reporting(0);
$dsn = 'mysql:host=localhost;dbname=php_project';
$username = 'root';
$password = '';

// try {
$db = new PDO($dsn, $username, $password);

include("../model/PDOOperation.php");



?>
