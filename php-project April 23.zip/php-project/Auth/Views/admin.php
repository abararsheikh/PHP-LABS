
<div id="adminLogin"></div>
<script src="/Assets/js/adminLogin.js"></script>