<?php

namespace Project\Classes\Config;


class PaymentKeys {
  const STRIPE = [
    'secret_key' => 'sk_test_LX2qjFDrYC7EBnaJ5QOPzpAn',
    'publishable_key' => 'pk_test_vjNKs1oMN2PS4LLBQONPycsV',
    'actionPath' => '/payment/stripe'
  ];
}