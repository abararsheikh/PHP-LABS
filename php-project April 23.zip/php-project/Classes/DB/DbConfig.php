<?php
namespace Project\Classes\DB;

/**
 * Class DbConfig
 * Database config file
 * @package Project\Classes\DB
 */
class DbConfig {
  const SERVER = 'localhost:3306';
  const DB_USER = 'root';
  const DB_PASS = '';
  const DB_NAME = 'php_project';

//  const DB_USER = 'aircmiao_yi_php';
//  const DB_PASS = 'a12345';
//  const DB_NAME = 'aircmiao_yi_phpproject';
}