<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Title</title>
</head>
<body>
  <h1>hello admin</h1>
  <?php use Project\Classes\Router\Nav;
  Nav::drawMenu('admin'); ?>

</body>
</html>