
<script src="/Assets/js/jquery.min.js"></script>
<script src="/Assets/js/bootstrap.min.js"></script>
<link href="/Assets/css/bootstrap.min.css" type="text/css" rel="stylesheet">


<div class="pull-right">
  <div id="login"></div>
</div>

<div id="menuDisplay" data-menuName="Main"></div>
<script src="/Assets/js/authApp.js"></script>
<script src="/Assets/js/MenuDisplay.js"></script>



