<?php
/**
 * @Author Yi Zhao
 *
 */

namespace Project\Validation;


class RegisterValidator extends Validator{
  public function username($value) {

  }
}