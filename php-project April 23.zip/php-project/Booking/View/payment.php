<?php
    session_start();
    //var_dump($_SESSION);
?>

<html>
    <head>
        <title>Thank You Page</title>
    </head>

    <body>
        <p>Redirect To Homepage<spam id="timer"></spam></p>
    </body>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
    <script type="text/javascript" src="../../Assets/js/booking/payment.js"></script>

</html>