
<div id="main">
    <h1 class="top">Error</h1>
    <p><?php echo $error; ?></p>
</div>

