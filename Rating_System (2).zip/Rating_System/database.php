
<?php
/*
$rating_tableName  = 'ratings';
$rating_unitwidth  = 15;
$rating_dbname  = 'php_project';
$units=5;

$dsn = 'mysql:host=localhost;dbname=php_project';
$username = 'root';
$password = '';

try{
    $db = new PDO($dsn,$username,$password);
    $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    echo "connected" ." <br/>";
}
catch(PDOException $e)
{
    $error_message = $e->getMessage();

    echo $error_message;

}
*/




$rating_tableName     = 'ratings';
$rating_unitwidth     = 15;
$rating_dbname        = 'php_project';
$units=5;
function connect(){
    $host="localhost";
    $uname="root";
    $pass="";
    $rating_dbname   = 'php_project';

    $con = mysql_connect($host,$uname,$pass);

    if (!$con)
    {
        die('Could not connect: ' . mysql_error());
    }
    mysql_select_db($rating_dbname, $con);}



?>

