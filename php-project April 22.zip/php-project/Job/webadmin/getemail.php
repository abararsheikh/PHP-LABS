<?php
//require_once 'conn.php';
//$db=Database::getDB();
//$sql  ="SELECT * FROM xinxi";
//$result = $db->query($sql);
//$webadmin($result->fetchAll());
//$jproducts=json_encode($$webadmin);
//foreach ($result as $product){
 //   echo $webadmin['xinxi'].":".$webadmin['']."<br />";
//}