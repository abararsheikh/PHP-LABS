<?php
namespace Project\Classes\DB;
/**
 * @Author Yi Zhao
 *
 */

class DbConfig {
  const SERVER = 'localhost:3306';
  const DB_USER = 'root';
  const DB_PASS = '';
  const DB_NAME = 'php_project';
}