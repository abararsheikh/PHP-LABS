<?php
?>
<div class="product">
    Rate : Movie
    <div id="rating_<?php echo $displayMovie['film_id']; ?>" class="ratings">
        <div class="star_1 ratings_stars"></div>
        <div class="star_2 ratings_stars"></div>
        <div class="star_3 ratings_stars"></div>
        <div class="star_4 ratings_stars"></div>
        <div class="star_5 ratings_stars"></div>
        <div class="total_votes">vote data</div>

    </div>
</div>
