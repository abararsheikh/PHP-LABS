<?php
?>

<div id ="header">
        <div class="logo">
        <a href="#">Welcome to admin page</a>
        </div>
 </div>