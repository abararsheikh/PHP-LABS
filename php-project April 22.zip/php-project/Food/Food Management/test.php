<?php
?>
<html>
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=Edge">
    <link href="../../Assets/css/bootstrap.min.css" rel="stylesheet" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <script src="../../Assets/js/jquery.min.js" ></script>
    <script src="../../Assets/js/bootstrap.min.js" ></script>
    <link rel="stylesheet" type="text/css" href="../../Assets/css/food-shopping-cart.css" />
    <script src="../../Assets/js/food_shopping_cart.js"></script>
</head>
<main>
    <div class="row">

    <img style="background-color: black;" src="../../Assets/image/food/food1.jpg" class="img-responsive img-rounded col-md-3" width="280" height="220"/>
    <img src="../../Assets/image/food/food1.jpg" class="img-responsive img-rounded col-md-3" width="280" height="220"/>

        <img src="../../Assets/image/food/food1.jpg" class="img-responsive img-rounded col-md-3" width="280" height="220"/>
        <img src="../../Assets/image/food/food1.jpg" class="img-responsive img-rounded col-md-3" width="280" height="220"/>
        <img src="../../Assets/image/food/food1.jpg" class="img-responsive img-rounded col-md-3" width="280" height="220"/>
</div>
</main>
</html>
