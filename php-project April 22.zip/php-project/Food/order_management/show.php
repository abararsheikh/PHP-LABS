
<table class="table table-hover">
                     <thead><td>Food</td><td>Price(CAD)</td><td>Quantity</td><td>Size</td><td>Amount(CAD)</td><td>Cinema</td><td>Delivery time</td><td>Operation</td></thead>

    <tr style="background-color:salmon;"><td>2012-3-6</td><td>Order ID:0001</td>
        <td>Contact number: 6477725042</td><td colspan="2"></td><td>State: Successful deal</td><td>Total Amount:$100</td><td><a>Delete</a></td></tr>
     <tr>                <td rowspan="4"><a href="#"><img src="../../Assets/image/food/food1.jpg" width="130" height="95"/></a></td>
         <td rowspan="4">2.00</td>
         <td rowspan="4">5</td>
         <td rowspan="4">Large</td>
         <td rowspan="4">10.00</td>
         <td rowspan="4">Cinema1</td>
         <td rowspan="4">XXXX</td>
         <td rowspan="2">

            <p> <a htef="" style="cursor: pointer;text-decoration: none;">Make a comment</a></p>
         </td>

     </tr>


                     <tr></tr>
                     <tr>

                     </tr>
                     <tr></tr>
    <tr>                <td rowspan="4"><a href="#"><img src="../../Assets/image/food/food1.jpg" width="130" height="95"/></a></td>
        <td rowspan="4">2.00</td>
        <td rowspan="4">5</td>
        <td rowspan="4">small</td>
        <td rowspan="4">10.00</td>
        <td rowspan="4">Cinema2</td>
        <td rowspan="4">XXXX</td>
        <td rowspan="2">
            <p> <a htef="" style="cursor: pointer;text-decoration: none;">Make a comment</a></p>

        </td>


    </tr>
    <tr></tr>
    <tr>

    </tr>
    <tr></tr>
    <tr style="background-color:salmon;"><td>2012-3-6</td><td>Order ID:0001</td>
        <td>Contact number: <input type="text"/></td><td colspan="2"></td><td>State: Unpaid</td><td>Total Amount:$100</td><td><button class="btn pay">Pay now</button></td></tr>
    <tr>                <td rowspan="4"><a href="#"><img src="../../Assets/image/food/food1.jpg" width="130" height="95"/></a></td>
        <td rowspan="4">2.00</td>
        <td rowspan="4">5</td>
        <td rowspan="4">Large</td>
        <td rowspan="4">10.00</td>
        <td rowspan="4">Cinema1</td>
        <td>XXXX</td>
        <td rowspan="2">


        </td>

    </tr>


    <tr></tr>
    <tr>

    </tr>
    <tr></tr>
    <tr>                <td rowspan="4"><a href="#"><img src="../../Assets/image/food/food1.jpg" width="130" height="95"/></a></td>
        <td rowspan="4">2.00</td>
        <td rowspan="4">5</td>
        <td rowspan="4">small</td>
        <td rowspan="4">10.00</td>
        <td rowspan="4">Cinema2</td>
        <td>XXXX</td>
        <td rowspan="2">


        </td>

    </tr>
    <tr></tr>
    <tr>

    </tr>
    <tr></tr>
                 </table>
