<?php
require_once "Database.php";
class OrderDB
{   public static function getAll(){


    }

}