import React from 'react';
import ReactDOM from 'react-dom';
import EditorContainer from './components/EditorContainer';

ReactDOM.render(<EditorContainer />, document.querySelector('#menuEditor'));
