<?php
require_once 'database.php';
$db = Database::getDB();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
Select Category: <select name="category" id="category">

</select>
<input type="submit" id="getprod" value="Search">
<div id="prodlist">

</div>

<div id ="staffDetails">

</div>

<script type="text/javascript" src="http://code.jquery.com/jquery-latest.min.js"></script>
<script>
    $(document).ready(function(){
        $.getJSON('getDepartment.php', function(data){
            var cat = "";
            $.each(data, function(index,category){

                cat += '<option value="' + category.department + '">' + category.department + '</option>';
            })
            $('#category').html(cat);
        });

        $('#category').change(function(){
           // alert('aaa');
            var cateee = $('#category').val();
            $.getJSON('getName.php',{cat : cateee}, function (data) {
                var result ="<ul>";
                $.each(data, function(index,product){

                  //  result += "<li>" + product.fname + " ,  " + product.lname + "</li>";
                    result += "<li>" +"<a href id='product.id'>"+ product.fname + " ,  " + product.lname + "<a href>"+ "</li>";
                 //   result+="<input type='hidden' name='getname'>"+ product.id + "</input>";

                });
                result += "</ul>";

                $('#prodlist').html(result);
            });
        })

        $('#prodlist').click(function(){
            alert('test');
            var staff = $('#prodlist').val();

            $.getJSON('getStaff.php',{cat : staff}, function (data) {
                var result ="<ul>";
                $.each(data, function(index,product){
                    //  result += "<li>" + product.fname + " ,  " + product.lname + "</li>";
                    result += "<li>" + product.fname + " ,  " + product.lname +  "</li>";
                });
                result += "</ul>";

                $('#prodlist').html(result);
            });
        })
    });
</script>
</body>
</html>