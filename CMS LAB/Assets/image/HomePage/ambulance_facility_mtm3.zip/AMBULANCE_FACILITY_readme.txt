This file requires third party Software to be viewed. It is comprised of geographical and atribute information.

Geographic data contained in this dataset best viewed with the Toronto Centreline file as a background. 


Column name  
======================================
ADD_PT_ID = Unique geospatial identifier for each addess point
X = X
Y = Y
LONGITUDE = LONGITUDE
LATITUDE = LATITUDE
EMS_NAME = Station name
EMS_ADDRES = City of Toronto address
 
